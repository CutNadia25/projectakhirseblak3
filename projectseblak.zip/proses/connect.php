<?php
  $conn = mysqli_connect("localhost","root","","db_seblakkuyy");
  if(!$conn){
    echo "Gagal";
  }
?>