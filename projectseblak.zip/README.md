##	Pemilik/Admin(1)
•	Melihat Laporan
•	Menambah/mengubah/menghapus daftar menu beserta harga
•	Menambah/mengubah/mengapus user
##	Pelayan(2)
•	Melihat harga dan total harga pesananan
•	Konfirmasi Pembayaran
•	Membuat bukti pembayaran
•	Menerima pesanan
•	Konfirmasi terima pesanan
•	Mengubah status pesanan “Selesai dibuat”
•	Membuat pesanan

##	Pelanggan(3)
•	Dapat membuat akun
•	Masuk
•	Melihat menu
•	Memasukkan menu  kedalam keranjang
•	Melakukan pemesanan
•	Dapat memilih metode pembayaran
•	Melacak/melihat status pemesanan

##	Kurir(4)
•	Memiliki akses ke daftar pemesanan yang harus mereka antar
•	Melihat detail alamat dan pengiriman
•	Status pembayaran

## Pemilik/Admin(1)
•	Report
•	Daftar Menu
•	user
•	pesanan
##	Pelayan
•	daftar menu
•	pesanan

##	Pelanggan
•	Dapat membuat akun
•	pesanan

##	Kurir
•	pesanan
•	pengiriman
